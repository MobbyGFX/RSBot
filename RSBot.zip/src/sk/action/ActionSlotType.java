package sk.action;

/**
 * The type of the slot in the ActionBar
 * 
 * @author Strikeskids
 * 
 */
public enum ActionSlotType {
	NOTHING, ABILITY, ITEM;
}
