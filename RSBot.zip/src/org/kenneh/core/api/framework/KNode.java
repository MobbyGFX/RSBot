package org.kenneh.core.api.framework;

public interface KNode {
	
	public abstract boolean canActivate();
	public abstract void activate();

}
