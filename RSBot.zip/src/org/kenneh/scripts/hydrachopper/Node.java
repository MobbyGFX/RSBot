package org.kenneh.scripts.hydrachopper;

public interface Node {
	public abstract boolean activate();
	public abstract void execute();
}